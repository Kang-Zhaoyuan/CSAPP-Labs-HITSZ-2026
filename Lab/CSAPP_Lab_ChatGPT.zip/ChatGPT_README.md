# 计算机体系结构 CPU 优化专题实验 (HITSZ Architecture Lab 1~3) 上下文指南

本压缩包专为上传至 ChatGPT (GPT-4o / GPT-4.5 / o1 / o3-mini 等模型) 设计。已剔除冗余的二进制垃圾文件与未压缩的大图，提取了核心源码与完整 Markdown 指导书，便于 AI 快速索引、直接阅读与精准分析。

---

## 📁 目录组织结构

### 1. `实验代码/` (核心源代码工程，无需手动解压 tar 包即可直接阅读)
- **`lab1/` (实验一：编写矩阵乘法 - 汇编入门与 SIMD 向量化)**
  - `src/lab1/gemm_kernel.S`: 核心 GEMM 汇编 Kernel（AT&T x86-64 汇编、AVX 向量化）
  - `src/lab1/gemm.cpp`: C++ 矩阵乘法驱动与基准
  - `src/lab1/test_gemm_kernel.cpp`: 测试用例与正确性校验
  - `src/lab1/print_integer.S`: 汇编打印整数示例
  - `CMakeLists.txt` 及构建环境脚本
- **`lab2/` (实验二：存储层次结构与 Cache 优化)**
  - `src/lab2/gemm_kernel_opt_loop.cpp` / `.S`: 循环分块 (Blocking) 与循环展开
  - `src/lab2/gemm_kernel_opt_prefetch.cpp` / `.S`: 软件预取 (Prefetch) 优化
  - `src/lab2/gemm_kernel_baseline.cpp` / `.S`: 基准对比实现
  - `src/lab2/test_gemm_kernel_opt_*.cpp`: 测试集
- **`lab3/` (实验三：指令级并行与多线程优化)**
  - `src/lab3/openmp_gemm_opt.cpp` / `openmp_gemm_baseline.cpp`: OpenMP 多线程并行实现
  - `src/lab3/gemm_kernel_opt_avx.cpp` / `.S`: AVX 向量化与寄存器重命名优化
  - `src/lab3/gemm_kernel_opt_loop_unrolling.cpp` / `.S`: 深度循环展开
  - `src/lab3/test_openmp_gemm.cpp`: 多线程性能与正确性测试

### 2. `实验指导书_Markdown/` (结构化文本，最适合 LLM 检索)
- `README.md`、`00_课程概况.md`、`01_作业提交说明.md`
- `实验1/`: 实验1完整指导书（含 `实验1指导书汇总.md` 以及各小节 `00_实验概述.md` ~ `05_练习4.md`）
- `实验2/`: 实验2完整指导书（含 `实验2指导书汇总.md` 以及各小节分块/预取指导）
- `实验3/`: 实验3完整指导书（含 `实验3指导书汇总.md`、`05_实验报告要求.md` 等）
- `assets/`: 原理图、AVX 寄存器分配图、Cache 映射图、分块矩阵图（轻量 PNG/SVG）。

### 3. `实验报告/`
- `1 CPU优化专题（实验1~3）报告模板.docx`: 官方实验报告模板文件，包含背景、原理、优化思路、实验数据表格与分析大纲。

### 4. `参考资料与PDF指导书/`
- `x86-64-reference.pdf`: x86-64 机器指令手册与寄存器速查。
- `实验1指导书汇总.pdf`、`实验2指导书汇总.pdf`、`实验3指导书汇总.pdf`: 官方排版 PDF 全本。
- `课程概况.pdf`、`作业提交说明.pdf`: 课程要求与平台说明。

### 5. `原始实验包/`
- `lab1.tar.gz`、`lab2.tar.gz`、`lab3.tar.gz`: 官方发布的原始 tarball 归档。

---

## 🎯 常见问答任务定位
- **汇编代码编写/补全**：参见 `实验代码/labX/src/labX/` 中的 `.S` 和 `.cpp` 文件。
- **实验原理与参数要求**：参见 `实验指导书_Markdown/` 中对应章节的 `.md` 文件。
- **实验报告撰写与表格填充**：参见 `实验报告/1 CPU优化专题（实验1~3）报告模板.docx`。
